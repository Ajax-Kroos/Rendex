import os
import math
from itertools import combinations, permutations

print("Ingrese [1] si desea ingresar una sola cadena de palabras y numeros")
print("Ingrese [0] si desea ingresar varios terminos separados")

Quest_1 = int(input("\n\tQue opcion desea elegir >> "))
while Quest_1 != 1  and Quest_1 != 0:
    Quest_1 = int(input("\n\tQue opcion desea elegir >> "))
clear = lambda: os.system('cls')

def SelectOpc():
    if Quest_1 == 1:
        Q1Opc1()
    elif Quest_1 == 0:
        Q1Opc2()
    else:
        print("You make a mistake try again")

def Q1Opc1():
    SetOfTerms = set()
    SetLetters = set()

    def Q2Opc1():

        mujica = LongCP / 2
        for comb in combinations(BitermList, int(mujica)):
            my_list = list(comb)
            PoPassword = str("".join(my_list))

            for j in range(len(PoPassword)):
                Condicion = True
                for i in range(len(PoPassword)):
                    Selection = PoPassword[i:i + j + 1]

                    try:
                        eval(Selection)
                    except NameError:
                        Condicion = True
                    except SyntaxError:
                        Condicion = True

                    if Condicion == True:
                        forms = PoPassword[:i] + str(Selection.upper()) + PoPassword[i + j + 1:]
                        SetOfTerms.add(forms)

                    Condicion = False

        Quest_3 = str(input("\n\tDesea guardar las passwords (Y/n) >> "))
        while Quest_3 != 'Y' and Quest_3 != 'y' and Quest_3 != 'N' and Quest_3 != 'n':
            Quest_3 = str(input("\n\tDesea guardar las passwords (Y/n) >> "))
        if Quest_3 == 'Y' or Quest_3 == 'y':
            file = open('Password Generator.txt', 'w')

            for passwords in SetOfTerms:
                file.write(passwords + '\n')



    def Q2Opc2():
        mujica = LongCP / 2

        for perm in permutations(BitermList, int(mujica)):
            my_list = list(comb)
            PoPassword = str("".join(my_list))

            for j in range(len(PoPassword)):
                Condicion = True
                for i in range(len(PoPassword)):
                    Selection = PoPassword[i:i + j + 1]

                    try:
                        eval(Selection)
                    except NameError:
                        Condicion = True
                    except SyntaxError:
                        Condicion = True

                    if Condicion == True:
                        forms = PoPassword[:i] + str(Selection.upper()) + PoPassword[i + j + 1:]
                        SetOfTerms.add(forms)
                    Condicion = False

        Quest_3 = str(input("\n\tDesea ver las contraseñas (Y/n) >> "))
        while Quest_3 != 'Y' and Quest_3 != 'y' and Quest_3 != 'N' and Quest_3 != 'n':
            Quest_3 = str(input("\n\tDesea ver las contraseñas (Y/n) >> "))
        if Quest_3 == 'Y' or Quest_3 == 'y':
            file = open('Passwordgenerator.list', 'w')

            for passwords in SetOfTerms:
                file.write(passwords)





    ArrayOfValues = str(input("\n\tAll Posible Chars >> "))

    """
    for letters in ArrayOfValues:
        SetLetters.add(str(letters))

    The_list = list(SetLetters)

    ArrayOfValues = str("".join(The_list))
    """
    #Activar para caracteres mas dispersos. Pero faltaria desactivar el Biterm

    BitermList = []
    for long in range(0, len(ArrayOfValues) + 1):
        if long == 0:
            BitermI = str(ArrayOfValues[long:long + 1])

            BitermList.append(BitermI)
        elif long == len(ArrayOfValues):
            Biterm = str(ArrayOfValues[long - 1:long + 1]) + str(BitermI)
            BitermL = str(ArrayOfValues[long - 1:long + 1])

            BitermList.append(BitermL)
        else:
            Biterm = str(ArrayOfValues[long - 1:long + 1])

        try:
            BitermList.append(Biterm)
        except NameError:
            pass
    #ARMADO DE COMBINACIONES
    clear()
    LongCP = int(input("\n\tDe que longitud quieres las combinaciones o permutaciones >> "))
    while LongCP < 1 or LongCP > 20:
        LongCP = int(input("\n\tDe que longitud quieres las combinaciones o permutaciones >> "))

    Combinaciones = math.factorial(len(BitermList))/(math.factorial(int(len(BitermList)) - int(LongCP/2)) * math.factorial(int(LongCP/2))) * int(LongCP) * (int(LongCP) + 1) / 2

    Pemutaciones = math.factorial(len(BitermList))/(math.factorial(len(BitermList) - LongCP))
    print(f"\nSe calcula hallar {Combinaciones} combinaciones y {Pemutaciones} permutaciones aproximadamente.")
    print(f"Si fuesen Combinacion se calcula: {Combinaciones * 8 / 1000000} MB. ")
    print(f"Si fuesen Permutacion se calcula: {Pemutaciones * 8 / 1000000} MB.")
    print("Ingrese [1] para hallar todas las combinaciones.")
    print("Ingrese [0] para hallar todas las permutaciones.")
    Quest_2 = int(input("\n\tQue opcion tomara >> "))

    while Quest_2 != 1 and Quest_2 != 0:
        Quest_2 = int(input("\n\tQue opcion tomara >> "))

    if Quest_2 == 1:
        Q2Opc1()
    elif Quest_2 == 0:
        Q2Opc2()

    #Contruccion de alternativas




def Q1Opc2():
    NumberOfWords = int(input("\n\tNumber of words >> "))
    while NumberOfWords < 1:
        NumberOfWords = int(input("\n\tNumber of words >> "))
    ListOfWords = []
    TotalLong = 0
    MayorChar = 0
    MenorChar = 20
    SetOfTerms = set()



    for Terms in range(1, NumberOfWords + 1):
        Words = str(input(f"\tWord {Terms} >> "))
        ListOfWords.append(Words)

    #ARMADO DE COMBINACIONES

    for long in range(NumberOfWords):
        Longitud = str(len(str(ListOfWords[int(long)])))

        TotalLong = TotalLong + int(Longitud)


        if int(Longitud) > int(MayorChar):
            MayorChar = Longitud

        if int(Longitud) < int(MenorChar):
            MenorChar = Longitud

    print(f"\nLongitud promedio de las palabras es: {round(TotalLong / NumberOfWords, 3)}")
    print(f"La palabra con menor longitud posee {MenorChar} caracteres")
    print(f"La palabra con mayor longitud posee {MayorChar} caracteres")

    NumberOfObjetcsPerm = int(input("\n\tDe cada cuantos objetos dispondra la permutacion >> "))


    try:
        NumPerm = math.factorial(len(ListOfWords)) / math.factorial(len(ListOfWords) - NumberOfObjetcsPerm)
    except ValueError:
        print("Se necesitan mas palabras para la permutacion.")

    print(f"\nSe calcula {NumPerm} permutaciones")
    NumPPass = (int(TotalLong / NumberOfWords) * NumberOfObjetcsPerm * (int(TotalLong / NumberOfWords) * NumberOfObjetcsPerm - 1) / 2) * NumPerm
    print(f"Se calcula habra {NumPPass} passwords aproximadamente")
    print(f"Se calcula ocupar {NumPPass * 64 / 8 / 1000000 } MB.")

    Deccision = str(input("\n\tDesea prosesar todas las permutaciones (Y/n) >> "))
    while Deccision != 'n' and Deccision != 'N' and Deccision != 'Y' and Deccision != 'y':
        Deccision = str(input("\n\tDesea prosesar todas las permutaciones (Y/n) >> "))

    if Deccision == 'Y' or Deccision == 'y':
        for perm in permutations(ListOfWords, NumberOfObjetcsPerm):
            my_list = list(perm)
            PoPassword = str("".join(my_list))

            for j in range(len(PoPassword)):
                Condicion = True
                for i in range(len(PoPassword)):
                    Selection = PoPassword[i:i + j + 1]

                    try:
                        eval(Selection)
                    except NameError:
                        Condicion = True
                    except SyntaxError:
                        Condicion = True

                    if Condicion == True:
                        forms = PoPassword[:i] + str(Selection.upper()) + PoPassword[i + j + 1:]
                        SetOfTerms.add(forms)
                    Condicion = False

    #Construccion de las contraseñas

    Quest_3 = str(input("\n\tDesea guardar las passwords (Y/n) >> "))
    while Quest_3 != 'Y' and Quest_3 != 'y' and Quest_3 != 'N' and Quest_3 != 'n':
        Quest_3 = str(input("\n\tDesea guardar las passwords (Y/n) >> "))
    if Quest_3 == 'Y' or Quest_3 == 'y':
        file = open('Password Generator.txt', 'w')

        for passwords in SetOfTerms:
            file.write(passwords + '\n')
    #Guardado de las contraseñas

SelectOpc()