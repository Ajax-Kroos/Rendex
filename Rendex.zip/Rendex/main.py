num_1 = int(input("Numero de caracteres: "))
lista_de_valores = ["a", "b", "c", "d", "e", "f", "g", "h", "i", 'j', "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
                    "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D",
                    "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X",
                    "Y", "Z"]

lista_de_constantes = ["b", "c", "d", "f", "g", "h", 'j', "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x",
                       "y", "z", "B", "C", "D", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V",
                       "W", "X", "Y", "Z"]
lista_de_vocales = ['a','e','i','o','u','A','E','I','O','U']


def main(Lista_de_Caracteres, Lista_de_Constantes, Lista_de_Vocales):
    base = 'aaaaaaa'
    Comb_omit = 0
    Compl_wordlist_8 = open('Compl_wordlist_8.txt', 'w')
    for i in Lista_de_Caracteres:
        for j in Lista_de_Caracteres:
            for k in Lista_de_Caracteres:
                if str(i) == str(j) and str(j) == str(k):
                    pass
                elif str(i) in Lista_de_Constantes and str(j) in Lista_de_Constantes and str(k) in Lista_de_Constantes:
                    pass
                elif str(i) in Lista_de_Vocales and str(j) in Lista_de_Vocales and str(k) in Lista_de_Vocales:
                    pass
                else:
                    for l in Lista_de_Caracteres:
                        if str(j) == str(k) and str(k) == str(l):
                            pass
                        elif str(j) in Lista_de_Constantes and str(k) in Lista_de_Constantes and str(
                                l) in Lista_de_Constantes:
                            pass
                        elif str(j) in Lista_de_Vocales and str(k) in Lista_de_Vocales and str(l) in Lista_de_Vocales:
                            pass
                        elif (int(Lista_de_Caracteres.index(str(l)))-int(Lista_de_Caracteres.index(str(i)))+
                              (int(Lista_de_Caracteres.index(str(k)))-int(Lista_de_Caracteres.index(str(i))))-
                              (int(Lista_de_Caracteres.index(str(l)))-int(Lista_de_Caracteres.index(str(j))))) == 3 or \
                                (int(Lista_de_Caracteres.index(str(l))) - int(Lista_de_Caracteres.index(str(i))) +
                                 (int(Lista_de_Caracteres.index(str(k))) - int(Lista_de_Caracteres.index(str(i)))) -
                                 (int(Lista_de_Caracteres.index(str(l))) - int(Lista_de_Caracteres.index(str(j))))) == -3:
                            pass

                        else:
                            for m in Lista_de_Caracteres:
                                if str(k) == str(l) and str(l) == str(m):
                                    Comb_omit += 1
                                    pass
                                elif str(k) in Lista_de_Constantes and str(l) in Lista_de_Constantes and str(
                                        m) in Lista_de_Constantes:
                                    pass
                                elif str(k) in Lista_de_Vocales and str(l) in Lista_de_Vocales and str(
                                        m) in Lista_de_Vocales:
                                    pass
                                elif (int(Lista_de_Caracteres.index(str(m))) - int(Lista_de_Caracteres.index(str(j))) +
                                      (int(Lista_de_Caracteres.index(str(l))) - int(
                                          Lista_de_Caracteres.index(str(j)))) -
                                      (int(Lista_de_Caracteres.index(str(m))) - int(
                                          Lista_de_Caracteres.index(str(k))))) == 3 or \
                                        (int(Lista_de_Caracteres.index(str(m))) - int(Lista_de_Caracteres.index(str(j))) +
                                         (int(Lista_de_Caracteres.index(str(l))) -
                                          int(Lista_de_Caracteres.index(str(j)))) -
                                         (int(Lista_de_Caracteres.index(str(m))) -
                                          int(Lista_de_Caracteres.index(str(k))))) == -3:
                                    pass
                                else:
                                    for n in Lista_de_Caracteres:
                                        if str(l) == str(m) and str(m) == str(n):
                                            Comb_omit += 1
                                            pass
                                        elif str(l) in Lista_de_Constantes and str(m) in Lista_de_Constantes and str(
                                                n) in Lista_de_Constantes:
                                            pass
                                        elif str(l) in Lista_de_Vocales and str(m) in Lista_de_Vocales and str(
                                                n) in Lista_de_Vocales:
                                            pass
                                        elif (int(Lista_de_Caracteres.index(str(n))) - int(
                                                Lista_de_Caracteres.index(str(k))) +
                                              (int(Lista_de_Caracteres.index(str(m))) - int(
                                                  Lista_de_Caracteres.index(str(k)))) -
                                              (int(Lista_de_Caracteres.index(str(n))) - int(
                                                  Lista_de_Caracteres.index(str(l))))) == 3 or (int(Lista_de_Caracteres.index(str(n))) - int(
                                                Lista_de_Caracteres.index(str(k))) +
                                              (int(Lista_de_Caracteres.index(str(m))) - int(
                                                  Lista_de_Caracteres.index(str(k)))) -
                                              (int(Lista_de_Caracteres.index(str(n))) - int(
                                                  Lista_de_Caracteres.index(str(l))))) == -3:
                                            pass
                                        else:
                                            for o in Lista_de_Caracteres:
                                                if str(m) == str(n) and str(n) == str(o):
                                                    Comb_omit += 1
                                                elif str(m) in Lista_de_Constantes and str(
                                                        n) in Lista_de_Constantes and str(o) in Lista_de_Constantes:
                                                    pass
                                                elif str(m) in Lista_de_Vocales and str(n) in Lista_de_Vocales and str(
                                                        o) in Lista_de_Vocales:
                                                    pass
                                                elif (int(Lista_de_Caracteres.index(str(o))) - int(
                                                        Lista_de_Caracteres.index(str(l))) +
                                                      (int(Lista_de_Caracteres.index(str(n))) - int(
                                                          Lista_de_Caracteres.index(str(l)))) -
                                                      (int(Lista_de_Caracteres.index(str(o))) - int(
                                                          Lista_de_Caracteres.index(str(m))))) == 3 or (int(Lista_de_Caracteres.index(str(o))) - int(
                                                        Lista_de_Caracteres.index(str(l))) +
                                                      (int(Lista_de_Caracteres.index(str(n))) - int(
                                                          Lista_de_Caracteres.index(str(l)))) -
                                                      (int(Lista_de_Caracteres.index(str(o))) - int(
                                                          Lista_de_Caracteres.index(str(m))))) == -3:
                                                    pass
                                                else:
                                                    for p in Lista_de_Caracteres:
                                                        if str(n) == str(o) and str(o) == str(p):
                                                            Comb_omit += 1
                                                            pass
                                                        elif str(n) in Lista_de_Constantes and str(
                                                                o) in Lista_de_Constantes and str(
                                                                p) in Lista_de_Constantes:
                                                            pass
                                                        elif str(n) in Lista_de_Vocales and str(
                                                                o) in Lista_de_Vocales and str(p) in Lista_de_Vocales:
                                                            pass
                                                        elif (int(Lista_de_Caracteres.index(str(p))) - int(
                                                                Lista_de_Caracteres.index(str(m))) +
                                                              (int(Lista_de_Caracteres.index(str(o))) - int(
                                                                  Lista_de_Caracteres.index(str(m)))) -
                                                              (int(Lista_de_Caracteres.index(str(p))) - int(
                                                                  Lista_de_Caracteres.index(str(n))))) == 3 or (int(Lista_de_Caracteres.index(str(p))) - int(
                                                                Lista_de_Caracteres.index(str(m))) +
                                                              (int(Lista_de_Caracteres.index(str(o))) - int(
                                                                  Lista_de_Caracteres.index(str(m)))) -
                                                              (int(Lista_de_Caracteres.index(str(p))) - int(
                                                                  Lista_de_Caracteres.index(str(n))))) == -3:
                                                            pass
                                                        else:
                                                            Password = str(i) + str(j) + str(k) + str(l) + str(m) + \
                                                                       str(n) + str(o) + base[-1:].replace('a', str(p))
                                                            Compl_wordlist_8.write("\n" + Password)

    print('El proceso ha terminado')

if __name__ == '__main__':
    main(lista_de_valores, lista_de_constantes, lista_de_vocales)


